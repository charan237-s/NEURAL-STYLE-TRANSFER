import React, { useState, useCallback } from 'react';
import { Upload, Download, Play, Pause, Settings, Zap, Brain, Palette, Camera } from 'lucide-react';
import ImageUpload from './components/ImageUpload';
import ParameterControls from './components/ParameterControls';
import ProcessingPanel from './components/ProcessingPanel';
import ResultsGallery from './components/ResultsGallery';

interface StyleTransferParams {
  contentWeight: number;
  styleWeight: number;
  iterations: number;
  learningRate: number;
  imageSize: number;
}

function App() {
  const [contentImage, setContentImage] = useState<string | null>(null);
  const [styleImage, setStyleImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentIteration, setCurrentIteration] = useState(0);
  const [results, setResults] = useState<string[]>([]);
  const [params, setParams] = useState<StyleTransferParams>({
    contentWeight: 1.0,
    styleWeight: 1000.0,
    iterations: 500,
    learningRate: 0.01,
    imageSize: 512
  });

  const handleStyleTransfer = useCallback(() => {
    if (!contentImage || !styleImage) return;
    
    setIsProcessing(true);
    setCurrentIteration(0);
    
    // Simulate neural style transfer processing
    const interval = setInterval(() => {
      setCurrentIteration(prev => {
        const newIteration = prev + 10;
        if (newIteration >= params.iterations) {
          clearInterval(interval);
          setIsProcessing(false);
          // Add simulated result
          setResults(prev => [...prev, contentImage]); // In real app, this would be the stylized image
          return params.iterations;
        }
        return newIteration;
      });
    }, 100);
  }, [contentImage, styleImage, params.iterations]);

  const resetTransfer = () => {
    setIsProcessing(false);
    setCurrentIteration(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="bg-white/5 backdrop-blur-lg border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl">
                  <Brain className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-white">Neural Style Transfer</h1>
                  <p className="text-purple-200">AI-Powered Artistic Style Transfer</p>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-sm text-purple-200">
                <Zap className="h-4 w-4" />
                <span>GPU Ready</span>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Image Uploads */}
            <div className="space-y-6">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="flex items-center space-x-2 mb-4">
                  <Camera className="h-5 w-5 text-purple-300" />
                  <h2 className="text-xl font-semibold text-white">Content Image</h2>
                </div>
                <ImageUpload
                  onImageUpload={setContentImage}
                  uploadedImage={contentImage}
                  label="Upload your photograph"
                  className="mb-4"
                />
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="flex items-center space-x-2 mb-4">
                  <Palette className="h-5 w-5 text-pink-300" />
                  <h2 className="text-xl font-semibold text-white">Style Image</h2>
                </div>
                <ImageUpload
                  onImageUpload={setStyleImage}
                  uploadedImage={styleImage}
                  label="Upload artistic style"
                  className="mb-4"
                />
              </div>

              {/* Style Transfer Controls */}
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Settings className="h-5 w-5 text-blue-300" />
                    <h2 className="text-xl font-semibold text-white">Controls</h2>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <button
                    onClick={handleStyleTransfer}
                    disabled={!contentImage || !styleImage || isProcessing}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-gray-500 disabled:to-gray-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 flex items-center justify-center space-x-2 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? (
                      <>
                        <Pause className="h-5 w-5" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-5 w-5" />
                        <span>Start Style Transfer</span>
                      </>
                    )}
                  </button>
                  
                  {isProcessing && (
                    <button
                      onClick={resetTransfer}
                      className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200"
                    >
                      Stop Processing
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Middle Column - Parameters */}
            <div className="space-y-6">
              <ParameterControls
                params={params}
                onParamsChange={setParams}
                disabled={isProcessing}
              />
              
              <ProcessingPanel
                isProcessing={isProcessing}
                currentIteration={currentIteration}
                totalIterations={params.iterations}
                contentImage={contentImage}
                styleImage={styleImage}
              />
            </div>

            {/* Right Column - Results */}
            <div>
              <ResultsGallery
                results={results}
                onClearResults={() => setResults([])}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
import React from 'react';
import { Sliders, Info } from 'lucide-react';

interface StyleTransferParams {
  contentWeight: number;
  styleWeight: number;
  iterations: number;
  learningRate: number;
  imageSize: number;
}

interface ParameterControlsProps {
  params: StyleTransferParams;
  onParamsChange: (params: StyleTransferParams) => void;
  disabled?: boolean;
}

const ParameterControls: React.FC<ParameterControlsProps> = ({
  params,
  onParamsChange,
  disabled = false
}) => {
  const updateParam = (key: keyof StyleTransferParams, value: number) => {
    onParamsChange({
      ...params,
      [key]: value
    });
  };

  const SliderControl = ({ 
    label, 
    value, 
    min, 
    max, 
    step, 
    onChange, 
    tooltip 
  }: {
    label: string;
    value: number;
    min: number;
    max: number;
    step: number;
    onChange: (value: number) => void;
    tooltip: string;
  }) => (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <label className="text-white font-medium text-sm">{label}</label>
          <div className="group relative">
            <Info className="h-4 w-4 text-white/50 hover:text-white/80 cursor-help" />
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-black/90 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10">
              {tooltip}
            </div>
          </div>
        </div>
        <span className="text-purple-300 text-sm font-mono">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        disabled={disabled}
        className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
        style={{
          background: `linear-gradient(to right, #a855f7 0%, #a855f7 ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.2) ${((value - min) / (max - min)) * 100}%, rgba(255,255,255,0.2) 100%)`
        }}
      />
      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 18px;
          width: 18px;
          border-radius: 50%;
          background: linear-gradient(45deg, #a855f7, #ec4899);
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }
        .slider::-moz-range-thumb {
          height: 18px;
          width: 18px;
          border-radius: 50%;
          background: linear-gradient(45deg, #a855f7, #ec4899);
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }
      `}</style>
    </div>
  );

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center space-x-2 mb-6">
        <Sliders className="h-5 w-5 text-blue-300" />
        <h2 className="text-xl font-semibold text-white">Neural Network Parameters</h2>
      </div>

      <div className="space-y-6">
        <SliderControl
          label="Content Weight"
          value={params.contentWeight}
          min={0.1}
          max={10}
          step={0.1}
          onChange={(value) => updateParam('contentWeight', value)}
          tooltip="Controls how much the output preserves the original content structure"
        />

        <SliderControl
          label="Style Weight"
          value={params.styleWeight}
          min={100}
          max={10000}
          step={100}
          onChange={(value) => updateParam('styleWeight', value)}
          tooltip="Controls how strongly the artistic style is applied"
        />

        <SliderControl
          label="Iterations"
          value={params.iterations}
          min={100}
          max={1000}
          step={50}
          onChange={(value) => updateParam('iterations', value)}
          tooltip="Number of optimization steps - more iterations = better quality but longer processing"
        />

        <SliderControl
          label="Learning Rate"
          value={params.learningRate}
          min={0.001}
          max={0.1}
          step={0.001}
          onChange={(value) => updateParam('learningRate', value)}
          tooltip="Step size for optimization - higher values converge faster but may be unstable"
        />

        <SliderControl
          label="Image Size"
          value={params.imageSize}
          min={256}
          max={1024}
          step={128}
          onChange={(value) => updateParam('imageSize', value)}
          tooltip="Output image resolution - larger sizes produce better quality but take longer"
        />
      </div>

      <div className="mt-6 p-4 bg-blue-500/20 border border-blue-400/30 rounded-xl">
        <div className="flex items-start space-x-3">
          <Info className="h-5 w-5 text-blue-300 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-100">
            <p className="font-medium mb-1">VGG19 Feature Extraction</p>
            <p className="text-blue-200">
              Using pre-trained VGG19 layers: conv1_1, conv2_1, conv3_1, conv4_1, conv5_1 for content loss 
              and conv1_1, conv2_1, conv3_1, conv4_1, conv5_1 for style loss with Gram matrices.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ParameterControls;
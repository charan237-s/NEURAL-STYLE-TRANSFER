import React from 'react';
import { Download, Trash2, Image as ImageIcon, Star } from 'lucide-react';

interface ResultsGalleryProps {
  results: string[];
  onClearResults: () => void;
}

const ResultsGallery: React.FC<ResultsGalleryProps> = ({
  results,
  onClearResults
}) => {
  const downloadImage = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `style-transfer-result-${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Star className="h-5 w-5 text-yellow-400" />
          <h2 className="text-xl font-semibold text-white">Results Gallery</h2>
        </div>
        {results.length > 0 && (
          <button
            onClick={onClearResults}
            className="text-red-400 hover:text-red-300 transition-colors duration-200 p-2 hover:bg-red-500/20 rounded-lg"
            title="Clear all results"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>

      {results.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ImageIcon className="h-8 w-8 text-white/50" />
          </div>
          <p className="text-white/70 mb-2">No results yet</p>
          <p className="text-white/50 text-sm">
            Complete a style transfer to see your artistic creations here
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {results.map((result, index) => (
            <div key={index} className="group relative">
              <div className="relative overflow-hidden rounded-xl border-2 border-white/20 group-hover:border-white/40 transition-all duration-200">
                <img
                  src={result}
                  alt={`Style transfer result ${index + 1}`}
                  className="w-full h-48 object-cover"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center space-x-3">
                  <button
                    onClick={() => downloadImage(result, index)}
                    className="bg-white/20 hover:bg-white/30 text-white p-3 rounded-full transition-all duration-200 backdrop-blur-sm"
                    title="Download image"
                  >
                    <Download className="h-5 w-5" />
                  </button>
                </div>

                {/* Result Number Badge */}
                <div className="absolute top-3 left-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                  #{index + 1}
                </div>
              </div>

              {/* Result Info */}
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-white font-medium text-sm">
                    Style Transfer Result {index + 1}
                  </span>
                  <span className="text-purple-300 text-xs">
                    Just now
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-xs text-white/60">
                  <span>512×512</span>
                  <span>•</span>
                  <span>Neural Style Transfer</span>
                  <span>•</span>
                  <span>VGG19</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Demo Info */}
      <div className="mt-6 p-4 bg-amber-500/20 border border-amber-400/30 rounded-xl">
        <div className="text-sm text-amber-100">
          <p className="font-medium mb-1">Demo Mode</p>
          <p className="text-amber-200">
            This is a UI demonstration. In a production environment, 
            this would connect to a Python backend with PyTorch for actual neural style transfer processing.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResultsGallery;
import React from 'react';
import { Brain, Zap, TrendingUp, Clock } from 'lucide-react';

interface ProcessingPanelProps {
  isProcessing: boolean;
  currentIteration: number;
  totalIterations: number;
  contentImage: string | null;
  styleImage: string | null;
}

const ProcessingPanel: React.FC<ProcessingPanelProps> = ({
  isProcessing,
  currentIteration,
  totalIterations,
  contentImage,
  styleImage
}) => {
  const progress = totalIterations > 0 ? (currentIteration / totalIterations) * 100 : 0;
  const estimatedTimeRemaining = isProcessing ? Math.max(0, (totalIterations - currentIteration) * 0.1) : 0;

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center space-x-2 mb-6">
        <Brain className="h-5 w-5 text-green-300" />
        <h2 className="text-xl font-semibold text-white">Processing Status</h2>
      </div>

      {!contentImage || !styleImage ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="h-8 w-8 text-white/50" />
          </div>
          <p className="text-white/70">Upload both content and style images to begin</p>
        </div>
      ) : !isProcessing && currentIteration === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="h-8 w-8 text-white" />
          </div>
          <p className="text-white font-medium mb-2">Ready to Start</p>
          <p className="text-white/70 text-sm">Click "Start Style Transfer" to begin neural processing</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/70">Progress</span>
              <span className="text-purple-300 font-mono">{currentIteration}/{totalIterations}</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-center text-purple-300 font-medium text-lg">
              {progress.toFixed(1)}%
            </div>
          </div>

          {/* Status Indicators */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 rounded-xl p-4">
              <div className="flex items-center space-x-2 mb-2">
                <TrendingUp className="h-4 w-4 text-green-300" />
                <span className="text-white/70 text-sm">Loss</span>
              </div>
              <div className="text-white font-mono text-lg">
                {isProcessing ? (Math.random() * 1000 + 500).toFixed(2) : '0.00'}
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Clock className="h-4 w-4 text-blue-300" />
                <span className="text-white/70 text-sm">ETA</span>
              </div>
              <div className="text-white font-mono text-lg">
                {isProcessing ? `${Math.ceil(estimatedTimeRemaining)}s` : '--'}
              </div>
            </div>
          </div>

          {/* Processing Animation */}
          {isProcessing && (
            <div className="flex items-center justify-center space-x-2 py-4">
              <div className="flex space-x-1">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"
                    style={{ animationDelay: `${i * 0.2}s` }}
                  />
                ))}
              </div>
              <span className="text-white/70 text-sm ml-3">
                Neural network optimizing...
              </span>
            </div>
          )}

          {/* Current Status */}
          <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-400/30 rounded-xl p-4">
            <div className="text-sm text-white/90">
              <div className="font-medium mb-1">Current Phase:</div>
              <div className="text-purple-200">
                {currentIteration < totalIterations * 0.3 
                  ? 'Extracting content features from VGG19...' 
                  : currentIteration < totalIterations * 0.6
                  ? 'Computing style Gram matrices...'
                  : currentIteration < totalIterations * 0.9
                  ? 'Optimizing content and style losses...'
                  : 'Finalizing stylized image...'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProcessingPanel;